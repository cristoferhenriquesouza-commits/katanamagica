# Katana Mágica — Forge 1.20.1 (47.x)

Mod com a katana vermelha 3D (convertida do seu `katana.bbmodel`, geometria idêntica) e 3 poderes.

## Como gerar o .jar
Requisitos: JDK 17 e internet.
1. Baixe o MDK do Forge 1.20.1 (47.3.0+) em https://files.minecraftforge.net e copie dele para esta pasta
   os arquivos `gradlew`, `gradlew.bat` e a pasta `gradle/` (o wrapper não vai neste zip).
2. Rode `./gradlew build` (Windows: `gradlew.bat build`).
3. O jar sai em `build/libs/katanamagica-1.0.0.jar` -> copie para a pasta `mods/`.
Para testar sem instalar: `./gradlew runClient`.

## Uso
- Item: `/give @s katanamagica:katana` (ou receita: netherite no diagonal + blaze rod; aba Combate no criativo).
- Teclas padrão (todas remapeáveis em Opções > Controles > "Katana Mágica"):
  **R** Parada Temporal · **G** Corte Relâmpago · **V** Corte Especial. Precisa segurar a katana.
- Config: `config/katanamagica-common.toml` (recargas, duração, raio, dano, distância, tempo de carga, entidades ignoradas).

## Estrutura
- `ability/` lógica de servidor: `AbilityManager`, `TimeStopManager`, `DashSession`, `ChargeSession`
- `network/` SimpleChannel: 1 pacote C2S (ativar) + 3 S2C (estado da parada, efeitos de tela, recargas)
- `client/` teclas, HUD, shader de inversão, câmera, partículas
- `config/`, `item/`, `registry/`, `util/Fx`
- `assets/.../models/item/` `katana_full.obj` (completa: lâmina, tsuka, tsuba, saya, máscara kitsune) e
  `katana_held.obj` (só lâmina+cabo, usada na mão); `katana.json` escolhe entre elas por perspectiva.
- `model_source/` seu .bbmodel original e prévia.

## Ajuste fino (não testado em jogo)
Este código foi escrito sem poder compilar/rodar o Minecraft. Pontos mais prováveis de precisar de ajuste:
- Posição/rotação da katana na mão: edite `display` em `models/item/katana_held.json` (Blockbench > aba Display).
- Se a lâmina aparecer com o fio para trás, troque `-90` por `90` no Y de `rotation`.
- Sons são vanilla (sem .ogg próprios).

## Compilar sem instalar nada (GitHub)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (inclusive `.github/`).
2. Aba **Actions** > workflow **build** > quando terminar, baixe o artefato **katanamagica-jar**.
3. O `.jar` de dentro vai na pasta `mods/` (Forge 1.20.1).
