package com.katanamagica.config;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** Configuracao COMMON (config/katanamagica-common.toml). O servidor e a autoridade. */
public final class KatanaConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue TS_COOLDOWN, TS_DURATION;
    public static final ForgeConfigSpec.DoubleValue TS_RADIUS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> TS_IGNORED;

    public static final ForgeConfigSpec.IntValue DASH_COOLDOWN, DASH_TICKS;
    public static final ForgeConfigSpec.DoubleValue DASH_DISTANCE, DASH_DAMAGE, DASH_WIDTH;

    public static final ForgeConfigSpec.IntValue SP_COOLDOWN, SP_CHARGE_TICKS;
    public static final ForgeConfigSpec.DoubleValue SP_DAMAGE, SP_RANGE, SP_WIDTH;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Poder 1 - Parada Temporal").push("time_stop");
        TS_COOLDOWN = b.comment("Recarga em segundos").defineInRange("cooldownSeconds", 90, 0, 3600);
        TS_DURATION = b.comment("Duracao em segundos").defineInRange("durationSeconds", 30, 1, 300);
        TS_RADIUS = b.comment("Raio de efeito em blocos").defineInRange("radius", 48.0D, 4.0D, 256.0D);
        TS_IGNORED = b.comment("IDs de entidades que nunca sao congeladas (ex: minecraft:ender_dragon)")
                .defineList("ignoredEntities", List.of(), o -> o instanceof String);
        b.pop();

        b.comment("Poder 2 - Corte Relampago").push("lightning_slash");
        DASH_COOLDOWN = b.comment("Recarga em segundos").defineInRange("cooldownSeconds", 6, 0, 3600);
        DASH_DISTANCE = b.comment("Distancia do avanco em blocos").defineInRange("distance", 14.0D, 3.0D, 48.0D);
        DASH_TICKS = b.comment("Duracao do avanco em ticks (menos = mais rapido)").defineInRange("ticks", 7, 2, 30);
        DASH_DAMAGE = b.comment("Dano por entidade atingida (1 = meio coracao)").defineInRange("damage", 14.0D, 0.0D, 1000.0D);
        DASH_WIDTH = b.comment("Largura do corte em blocos").defineInRange("width", 1.6D, 0.5D, 6.0D);
        b.pop();

        b.comment("Poder 3 - Corte Especial").push("special_slash");
        SP_COOLDOWN = b.comment("Recarga em segundos").defineInRange("cooldownSeconds", 25, 0, 3600);
        SP_CHARGE_TICKS = b.comment("Tempo de carga em ticks").defineInRange("chargeTicks", 45, 5, 400);
        SP_DAMAGE = b.comment("Dano do corte").defineInRange("damage", 60.0D, 0.0D, 10000.0D);
        SP_RANGE = b.comment("Alcance do corte em blocos").defineInRange("range", 18.0D, 3.0D, 64.0D);
        SP_WIDTH = b.comment("Largura do corte em blocos").defineInRange("width", 3.0D, 0.5D, 10.0D);
        b.pop();

        SPEC = b.build();
    }

    private KatanaConfig() {}
}
