package com.katanamagica.ability;

import com.katanamagica.config.KatanaConfig;
import com.katanamagica.network.FxPacket;
import com.katanamagica.network.ModNetwork;
import com.katanamagica.util.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Poder 3 - Corte Especial: carrega energia e libera um corte de dano elevado. */
final class ChargeSession {
    private final ServerPlayer player;
    private final ServerLevel level;
    private final int total;
    private int age;

    ChargeSession(ServerPlayer p) {
        this.player = p;
        this.level = p.serverLevel();
        this.total = KatanaConfig.SP_CHARGE_TICKS.get();
        Fx.sound(level, p.position(), SoundEvents.BEACON_ACTIVATE, 1.0F, 1.6F);
        Fx.sound(level, p.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 0.6F);
        ModNetwork.sendTo(p, new FxPacket(FxPacket.CHARGE_START, total, 1.0F, 0));
    }

    void abort() {
        ModNetwork.sendTo(player, new FxPacket(FxPacket.CHARGE_END, 0, 0.0F, 0));
    }

    /** @return true quando terminou (liberou ou cancelou). */
    boolean tick() {
        if (!player.isAlive() || player.serverLevel() != level || !AbilityManager.isHoldingKatana(player)) {
            abort();
            return true;
        }
        age++;
        float prog = Mth.clamp(age / (float) total, 0.0F, 1.0F);

        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 2, false, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 4, 1, false, false, false));

        chargeFx(prog);

        if (age % 8 == 0) {
            Fx.sound(level, player.position(), SoundEvents.BEACON_AMBIENT, 0.9F, 0.5F + prog * 1.5F);
        }
        if (age >= total) {
            release();
            return true;
        }
        return false;
    }

    private Vec3 hand() {
        Vec3 look = player.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        return player.getEyePosition().add(look.scale(0.8D)).add(right.scale(0.35D)).add(0, -0.55D, 0);
    }

    private void chargeFx(float prog) {
        RandomSource r = level.random;
        Vec3 base = player.position();
        Vec3 hand = hand();

        // espirais de energia convergindo para a katana
        for (int k = 0; k < 2 + (int) (prog * 3); k++) {
            double ang = age * 0.45D + k * (Math.PI * 2.0D / 3.0D);
            double rad = 1.5D - 0.5D * prog;
            Vec3 start = base.add(Math.cos(ang) * rad, 0.1D + ((age * 0.11D + k * 0.4D) % 1.9D), Math.sin(ang) * rad);
            Fx.energy(level, start, hand.subtract(start).scale(1.0D / 8.0D));
        }
        // anel de energia no chao
        for (int i = 0; i < 8; i++) {
            double ang = -age * 0.3D + i * (Math.PI / 4.0D);
            Fx.burst(level, Fx.RED, base.add(Math.cos(ang) * 1.7D, 0.08D, Math.sin(ang) * 1.7D), 1, 0.0, 0.0);
        }
        // aura da katana
        Fx.burst(level, ParticleTypes.ELECTRIC_SPARK, hand, 2 + (int) (prog * 4), 0.18, 0.08);
        Fx.burst(level, Fx.RED_BIG, hand, 1, 0.1, 0.0);
        // aura do corpo
        Fx.burst(level, Fx.RED, base.add(0, 1.0D, 0), 2, 0.45, 0.0);
        if (prog > 0.55F) {
            Fx.burst(level, ParticleTypes.END_ROD, base.add(0, 0.2D, 0), 1, 0.5, 0.06);
            Fx.burst(level, ParticleTypes.SOUL_FIRE_FLAME, base.add(0, 0.1D, 0), 1, 0.4, 0.05);
        }
        if (age % 6 == 0) {
            Fx.slash(level, hand, r.nextDouble() * Math.PI, 0.5D + prog * 0.9D);
        }
    }

    private void release() {
        Vec3 eye = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        double range = KatanaConfig.SP_RANGE.get();
        double width = KatanaConfig.SP_WIDTH.get();
        float damage = KatanaConfig.SP_DAMAGE.get().floatValue();

        Vec3 end = eye.add(dir.scale(range));
        var block = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (block.getType() != HitResult.Type.MISS) end = block.getLocation();
        Vec3 seg = end.subtract(eye);
        double len = seg.length();
        Vec3 segDir = len > 1.0E-4D ? seg.scale(1.0D / len) : dir;

        // ---- dano real
        AABB box = new AABB(eye, end).inflate(width + 1.0D);
        double len2 = Math.max(seg.lengthSqr(), 1.0E-4D);
        int hits = 0;
        for (Entity e : level.getEntities(player, box, x -> x instanceof LivingEntity le && le.isAlive() && !le.isSpectator())) {
            LivingEntity target = (LivingEntity) e;
            if (target instanceof Player other && !player.canHarmPlayer(other)) continue;
            if (target instanceof TamableAnimal t && t.isOwnedBy(player)) continue;
            Vec3 c = target.getBoundingBox().getCenter();
            double t = Mth.clamp(c.subtract(eye).dot(seg) / len2, 0.0D, 1.0D);
            Vec3 closest = eye.add(seg.scale(t));
            if (c.distanceTo(closest) > width + target.getBbWidth() * 0.5D) continue;

            target.invulnerableTime = 0;
            target.hurt(level.damageSources().playerAttack(player), damage);
            target.knockback(1.6D, -segDir.x, -segDir.z);
            target.setDeltaMovement(target.getDeltaMovement().add(0, 0.35D, 0));
            target.hurtMarked = true;
            hits++;
            impactFx(c);
        }

        // ---- efeitos visuais do golpe
        slashFx(eye, segDir, len);

        // pequeno avanco do jogador junto com o golpe
        player.setDeltaMovement(player.getDeltaMovement().add(segDir.x * 0.8D, 0.1D, segDir.z * 0.8D));
        player.hurtMarked = true;

        Vec3 pos = player.position();
        Fx.sound(level, pos, SoundEvents.WARDEN_SONIC_BOOM, 1.4F, 1.5F);
        Fx.sound(level, pos, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.2F, 1.3F);
        Fx.sound(level, pos, SoundEvents.PLAYER_ATTACK_SWEEP, 1.4F, 0.5F);
        if (hits > 0) Fx.sound(level, pos, SoundEvents.PLAYER_ATTACK_CRIT, 1.5F, 0.6F);

        ModNetwork.sendTo(player, new FxPacket(FxPacket.CHARGE_END, 0, 0.0F, 0));
        ModNetwork.sendTo(player, new FxPacket(FxPacket.FLASH, 8, 0.7F, 0xFFFFFF));
        Fx.screen(level, pos, 32, new FxPacket(FxPacket.SHAKE, 14, 0.9F, 0));
    }

    private void slashFx(Vec3 eye, Vec3 dir, double len) {
        // golpe principal: grande corte diagonal em "X" a frente do jogador
        Vec3 front = eye.add(dir.scale(Math.min(3.0D, len)));
        Fx.slash(level, front, -0.75D, 8.0D);
        Fx.slash(level, front, 0.75D, 6.5D);
        Fx.burst(level, ParticleTypes.FLASH, front, 1, 0.0, 0.0);
        // onda de cortes ao longo do alcance
        for (double d = 2.0D; d <= len; d += 2.0D) {
            Vec3 p = eye.add(dir.scale(d));
            Fx.slash(level, p, -0.75D, 4.0D + d * 0.12D);
            Fx.burst(level, ParticleTypes.SWEEP_ATTACK, p, 1, 0.0, 0.0);
            Fx.burst(level, ParticleTypes.END_ROD, p, 4, 0.5, 0.05);
        }
        // linha de energia vermelha e branca
        for (double d = 0.5D; d <= len; d += 0.35D) {
            Vec3 p = eye.add(dir.scale(d)).add(0, -0.2D, 0);
            Fx.burst(level, Fx.RED_BIG, p, 1, 0.12, 0.0);
            if (((int) (d * 10)) % 3 == 0) Fx.burst(level, Fx.WHITE, p, 1, 0.08, 0.0);
        }
        Fx.burst(level, ParticleTypes.EXPLOSION, eye.add(dir.scale(Math.min(len, 5.0D))), 1, 0.0, 0.0);
    }

    private void impactFx(Vec3 c) {
        for (int i = 0; i < 4; i++) Fx.slash(level, c, (i - 1.5D) * 0.6D, 3.0D + i * 0.4D);
        Fx.burst(level, ParticleTypes.CRIT, c, 30, 0.6, 0.6);
        Fx.burst(level, ParticleTypes.SWEEP_ATTACK, c, 1, 0.0, 0.0);
        Fx.burst(level, ParticleTypes.EXPLOSION, c, 1, 0.0, 0.0);
    }
}
