package com.katanamagica.ability;

import com.katanamagica.config.KatanaConfig;
import com.katanamagica.network.FxPacket;
import com.katanamagica.network.ModNetwork;
import com.katanamagica.network.TimeStopStatePacket;
import com.katanamagica.util.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Poder 1 - Parada Temporal (logica real, no servidor).
 *
 * - Seres vivos congelados: o LivingTickEvent e cancelado (ver CommonEvents), entao a IA, fisica,
 *   efeitos, animacoes e ataques deles simplesmente nao executam.
 * - Objetos (projeteis, itens, TNT, blocos caindo, minecarts, barcos, orbes): posicao/velocidade/gravidade
 *   sao guardadas e restauradas no fim; a cada tick ficam presos na posicao.
 * - Outros jogadores: movimento desfeito no servidor (teleport de volta) e entradas bloqueadas.
 * - O jogador que ativou e imune e continua se movendo e atacando.
 */
public final class TimeStopManager {

    private static final class Session {
        final UUID caster;
        final ResourceKey<Level> dim;
        final double radius;
        final int casterEntityId;
        int ticksLeft;
        Vec3 center;
        final Set<UUID> notified = new HashSet<>();

        Session(UUID caster, int casterEntityId, ResourceKey<Level> dim, int ticks, double radius, Vec3 center) {
            this.caster = caster; this.casterEntityId = casterEntityId; this.dim = dim;
            this.ticksLeft = ticks; this.radius = radius; this.center = center;
        }
    }

    private static final class FrozenObject {
        final Entity entity;
        final Vec3 pos;
        final Vec3 vel;
        final boolean noGravity;
        final int fuse;

        FrozenObject(Entity e) {
            this.entity = e;
            this.pos = e.position();
            this.vel = e.getDeltaMovement();
            this.noGravity = e.isNoGravity();
            this.fuse = e instanceof PrimedTnt t ? t.getFuse() : -1;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static final Map<UUID, FrozenObject> OBJECTS = new HashMap<>();
    private static final Map<UUID, Vec3> PLAYER_POS = new HashMap<>();

    // ------------------------------------------------------------------ consulta

    public static boolean isCaster(Entity e) {
        return SESSIONS.containsKey(e.getUUID());
    }

    public static boolean isFrozen(Entity e) {
        if (SESSIONS.isEmpty() || e.level().isClientSide) return false;
        if (!e.isAlive()) return false;
        if (e instanceof ServerPlayer sp && sp.isSpectator()) return false;
        if (SESSIONS.containsKey(e.getUUID())) return false;
        if (isIgnored(e)) return false;
        for (Session s : SESSIONS.values()) {
            if (e.level().dimension() != s.dim) continue;
            if (e instanceof Projectile pr && pr.getOwner() != null && pr.getOwner().getUUID().equals(s.caster)) continue;
            double r = s.radius;
            if (e.position().distanceToSqr(s.center) <= r * r) return true;
        }
        return false;
    }

    private static boolean isIgnored(Entity e) {
        var key = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return key != null && KatanaConfig.TS_IGNORED.get().contains(key.toString());
    }

    private static boolean isFreezableObject(Entity e) {
        return !(e instanceof LivingEntity) && (e instanceof Projectile || e instanceof ItemEntity
                || e instanceof ExperienceOrb || e instanceof PrimedTnt || e instanceof FallingBlockEntity
                || e instanceof AbstractMinecart || e instanceof Boat);
    }

    // ------------------------------------------------------------------ inicio / fim

    public static boolean start(ServerPlayer p) {
        if (SESSIONS.containsKey(p.getUUID())) return false;
        int ticks = KatanaConfig.TS_DURATION.get() * 20;
        double radius = KatanaConfig.TS_RADIUS.get();
        Session s = new Session(p.getUUID(), p.getId(), p.level().dimension(), ticks, radius, p.position());
        SESSIONS.put(p.getUUID(), s);

        ServerLevel level = p.serverLevel();
        Vec3 pos = p.position();
        Fx.sound(level, pos, SoundEvents.END_PORTAL_SPAWN, 1.0F, 1.8F);
        Fx.sound(level, pos, SoundEvents.BELL_RESONATE, 2.0F, 0.5F);
        Fx.sound(level, pos, SoundEvents.WARDEN_HEARTBEAT, 2.0F, 0.6F);
        Fx.sound(level, pos, SoundEvents.AMETHYST_BLOCK_RESONATE, 2.0F, 0.5F);
        shockwave(level, pos.add(0, 0.1D, 0));
        Fx.burst(level, ParticleTypes.FLASH, pos.add(0, 1.0D, 0), 1, 0.0, 0.0);
        Fx.screen(level, pos, radius + 16, new FxPacket(FxPacket.FLASH, 14, 1.0F, 0xFFFFFF));
        broadcast(p.server, s);
        return true;
    }

    /** Ondas de particulas se expandindo em aneis a partir do jogador. */
    private static void shockwave(ServerLevel level, Vec3 origin) {
        for (int ring = 0; ring < 3; ring++) {
            double speed = 0.5D + ring * 0.35D;
            for (int i = 0; i < 48; i++) {
                double a = i * (Math.PI * 2.0D / 48.0D);
                Vec3 v = new Vec3(Math.cos(a) * speed, 0.02D, Math.sin(a) * speed);
                Fx.directed(level, ring == 1 ? ParticleTypes.REVERSE_PORTAL : ParticleTypes.END_ROD, origin, v);
            }
        }
    }

    private static void broadcast(MinecraftServer server, Session s) {
        ServerLevel level = server.getLevel(s.dim);
        if (level == null) return;
        double r = s.radius + 16.0D;
        for (ServerPlayer pl : level.players()) {
            boolean isCaster = pl.getUUID().equals(s.caster);
            if ((isCaster || pl.position().distanceToSqr(s.center) <= r * r) && s.notified.add(pl.getUUID())) {
                ModNetwork.sendTo(pl, new TimeStopStatePacket(true, s.ticksLeft, s.casterEntityId, (float) s.radius));
            }
        }
    }

    private static void end(MinecraftServer server, Session s) {
        for (UUID id : s.notified) {
            ServerPlayer pl = server.getPlayerList().getPlayer(id);
            if (pl != null) ModNetwork.sendTo(pl, new TimeStopStatePacket(false, 0, s.casterEntityId, (float) s.radius));
        }
        ServerLevel level = server.getLevel(s.dim);
        ServerPlayer caster = server.getPlayerList().getPlayer(s.caster);
        if (level != null && caster != null) {
            Vec3 pos = caster.position();
            Fx.sound(level, pos, SoundEvents.BELL_RESONATE, 2.0F, 1.6F);
            Fx.sound(level, pos, SoundEvents.BEACON_DEACTIVATE, 2.0F, 1.2F);
            Fx.sound(level, pos, SoundEvents.END_PORTAL_SPAWN, 1.0F, 0.6F);
            for (int i = 0; i < 48; i++) {
                double a = i * (Math.PI * 2.0D / 48.0D);
                Vec3 v = new Vec3(-Math.cos(a) * 0.5D, 0.02D, -Math.sin(a) * 0.5D);
                Vec3 from = pos.add(Math.cos(a) * 12.0D, 0.1D, Math.sin(a) * 12.0D);
                Fx.directed(level, ParticleTypes.END_ROD, from, v);
            }
            Fx.burst(level, ParticleTypes.FLASH, pos.add(0, 1.0D, 0), 1, 0.0, 0.0);
            Fx.screen(level, pos, s.radius + 16, new FxPacket(FxPacket.FLASH, 14, 1.0F, 0xFFFFFF));
        }
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        if (SESSIONS.isEmpty() && OBJECTS.isEmpty() && PLAYER_POS.isEmpty()) return;

        Iterator<Session> it = SESSIONS.values().iterator();
        while (it.hasNext()) {
            Session s = it.next();
            ServerPlayer caster = server.getPlayerList().getPlayer(s.caster);
            if (caster == null || !caster.isAlive() || caster.level().dimension() != s.dim) {
                end(server, s);
                it.remove();
                continue;
            }
            s.center = caster.position();
            if (--s.ticksLeft <= 0) {
                end(server, s);
                it.remove();
                continue;
            }
            if (s.ticksLeft % 10 == 0) broadcast(server, s);
        }

        // captura de novos objetos / jogadores dentro do raio
        for (Session s : SESSIONS.values()) {
            ServerLevel level = server.getLevel(s.dim);
            if (level == null) continue;
            AABB box = new AABB(s.center, s.center).inflate(s.radius);
            for (Entity e : level.getEntities((Entity) null, box, TimeStopManager::isFreezableObject)) {
                if (isFrozen(e)) OBJECTS.computeIfAbsent(e.getUUID(), k -> new FrozenObject(e));
            }
            for (ServerPlayer pl : level.players()) {
                if (isFrozen(pl)) PLAYER_POS.computeIfAbsent(pl.getUUID(), k -> pl.position());
            }
        }

        // objetos: manter presos / liberar
        Iterator<Map.Entry<UUID, FrozenObject>> oi = OBJECTS.entrySet().iterator();
        while (oi.hasNext()) {
            FrozenObject fo = oi.next().getValue();
            Entity e = fo.entity;
            if (e.isRemoved()) { oi.remove(); continue; }
            if (isFrozen(e)) {
                e.setPos(fo.pos);
                e.setDeltaMovement(Vec3.ZERO);
                e.setNoGravity(true);
                if (e instanceof PrimedTnt t) t.setFuse(fo.fuse);
            } else {
                e.setNoGravity(fo.noGravity);
                e.setDeltaMovement(fo.vel);
                e.hurtMarked = true;
                oi.remove();
            }
        }

        // jogadores congelados: desfazer movimento
        Iterator<Map.Entry<UUID, Vec3>> pi = PLAYER_POS.entrySet().iterator();
        while (pi.hasNext()) {
            Map.Entry<UUID, Vec3> en = pi.next();
            ServerPlayer pl = server.getPlayerList().getPlayer(en.getKey());
            if (pl == null || !isFrozen(pl)) { pi.remove(); continue; }
            Vec3 pos = en.getValue();
            if (pl.position().distanceToSqr(pos) > 0.0004D) {
                pl.connection.teleport(pos.x, pos.y, pos.z, pl.getYRot(), pl.getXRot());
            }
            pl.setDeltaMovement(Vec3.ZERO);
            pl.fallDistance = 0;
        }
    }

    public static void clearAll() {
        for (FrozenObject fo : OBJECTS.values()) {
            if (!fo.entity.isRemoved()) {
                fo.entity.setNoGravity(fo.noGravity);
                fo.entity.setDeltaMovement(fo.vel);
            }
        }
        OBJECTS.clear();
        PLAYER_POS.clear();
        SESSIONS.clear();
    }

    private TimeStopManager() {}
}
