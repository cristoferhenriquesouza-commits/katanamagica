package com.katanamagica.ability;

import com.katanamagica.config.KatanaConfig;

public enum Ability {
    TIME_STOP(0),
    LIGHTNING_SLASH(1),
    SPECIAL_SLASH(2);

    public final int id;

    Ability(int id) { this.id = id; }

    public static Ability byId(int id) {
        for (Ability a : values()) if (a.id == id) return a;
        return null;
    }

    /** Recarga configurada em ticks. */
    public int cooldownTicks() {
        return switch (this) {
            case TIME_STOP -> KatanaConfig.TS_COOLDOWN.get() * 20;
            case LIGHTNING_SLASH -> KatanaConfig.DASH_COOLDOWN.get() * 20;
            case SPECIAL_SLASH -> KatanaConfig.SP_COOLDOWN.get() * 20;
        };
    }
}
