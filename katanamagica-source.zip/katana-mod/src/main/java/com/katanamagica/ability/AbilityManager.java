package com.katanamagica.ability;

import com.katanamagica.item.KatanaItem;
import com.katanamagica.network.CooldownSyncPacket;
import com.katanamagica.network.ModNetwork;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Ponto de entrada (servidor) das tres habilidades. Valida katana na mao, recargas e estado
 * ocupado, e delega para TimeStopManager / DashSession / ChargeSession.
 */
public final class AbilityManager {
    private static final Map<UUID, long[]> COOLDOWN_END = new HashMap<>();
    private static final Map<UUID, int[]> COOLDOWN_TOTAL = new HashMap<>();
    private static final Map<UUID, DashSession> DASHES = new HashMap<>();
    private static final Map<UUID, ChargeSession> CHARGES = new HashMap<>();

    public static boolean isHoldingKatana(Player p) {
        return p.getMainHandItem().getItem() instanceof KatanaItem || p.getOffhandItem().getItem() instanceof KatanaItem;
    }

    public static void request(ServerPlayer p, Ability ability) {
        if (!p.isAlive() || p.isSpectator()) return;
        if (!isHoldingKatana(p)) {
            p.displayClientMessage(Component.translatable("message.katanamagica.need_katana"), true);
            return;
        }
        if (TimeStopManager.isFrozen(p)) return;
        UUID id = p.getUUID();
        if (DASHES.containsKey(id) || CHARGES.containsKey(id)) return;

        int now = p.server.getTickCount();
        long[] end = COOLDOWN_END.computeIfAbsent(id, k -> new long[3]);
        if (end[ability.id] > now) {
            double secs = (end[ability.id] - now) / 20.0D;
            p.displayClientMessage(Component.translatable("message.katanamagica.cooldown", String.format("%.1f", secs)), true);
            return;
        }

        boolean started = switch (ability) {
            case TIME_STOP -> TimeStopManager.start(p);
            case LIGHTNING_SLASH -> { DASHES.put(id, new DashSession(p)); yield true; }
            case SPECIAL_SLASH -> { CHARGES.put(id, new ChargeSession(p)); yield true; }
        };
        if (started) {
            int cd = ability.cooldownTicks();
            end[ability.id] = now + cd;
            COOLDOWN_TOTAL.computeIfAbsent(id, k -> new int[3])[ability.id] = cd;
            sync(p);
        }
    }

    public static void tick(MinecraftServer server) {
        if (!DASHES.isEmpty()) {
            Iterator<DashSession> it = DASHES.values().iterator();
            while (it.hasNext()) if (it.next().tick()) it.remove();
        }
        if (!CHARGES.isEmpty()) {
            Iterator<ChargeSession> it = CHARGES.values().iterator();
            while (it.hasNext()) if (it.next().tick()) it.remove();
        }
    }

    public static void sync(ServerPlayer p) {
        int now = p.server.getTickCount();
        long[] end = COOLDOWN_END.getOrDefault(p.getUUID(), new long[3]);
        int[] total = COOLDOWN_TOTAL.getOrDefault(p.getUUID(), new int[3]);
        int[] remaining = new int[3];
        for (int i = 0; i < 3; i++) remaining[i] = (int) Math.max(0, end[i] - now);
        ModNetwork.sendTo(p, new CooldownSyncPacket(remaining, total.clone()));
    }

    /** Cancela avanco/carga em andamento (troca de dimensao, logout). */
    public static void cancelSessions(UUID id, boolean notifyClient) {
        DASHES.remove(id);
        ChargeSession c = CHARGES.remove(id);
        if (c != null && notifyClient) c.abort();
    }

    public static void clearAll() {
        DASHES.clear();
        CHARGES.clear();
        COOLDOWN_END.clear();
        COOLDOWN_TOTAL.clear();
    }

    private AbilityManager() {}
}
