package com.katanamagica.ability;

import com.katanamagica.config.KatanaConfig;
import com.katanamagica.network.FxPacket;
import com.katanamagica.network.ModNetwork;
import com.katanamagica.util.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/** Poder 2 - Corte Relampago: avanco em linha reta que corta tudo no caminho. */
final class DashSession {
    private final ServerPlayer player;
    private final ServerLevel level;
    private final Vec3 dir;
    private final double speed;
    private final double width;
    private final float damage;
    private final Set<Integer> hit = new HashSet<>();
    private int ticksLeft;

    DashSession(ServerPlayer p) {
        this.player = p;
        this.level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        if (p.onGround() && look.y < 0) look = new Vec3(look.x, 0, look.z); // nao cavar o chao
        if (look.lengthSqr() < 1.0E-4D) look = Vec3.directionFromRotation(0, p.getYRot());
        this.dir = look.normalize();
        int ticks = KatanaConfig.DASH_TICKS.get();
        this.ticksLeft = ticks;
        this.speed = KatanaConfig.DASH_DISTANCE.get() / ticks;
        this.width = KatanaConfig.DASH_WIDTH.get();
        this.damage = KatanaConfig.DASH_DAMAGE.get().floatValue();

        Vec3 pos = p.position().add(0, p.getBbHeight() * 0.5, 0);
        Fx.sound(level, pos, SoundEvents.TRIDENT_RIPTIDE_3, 1.2F, 1.4F);
        Fx.sound(level, pos, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 0.6F);
        Fx.sound(level, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.35F, 2.0F);
        Fx.burst(level, ParticleTypes.EXPLOSION, pos, 1, 0.0, 0.0);
        Fx.burst(level, ParticleTypes.ELECTRIC_SPARK, pos, 30, 0.6, 0.4);
        Fx.slash(level, pos.add(dir.scale(1.2)), 0.8, 3.0);
        ModNetwork.sendTo(p, new FxPacket(FxPacket.DASH, ticks, 1.0F, 0));
    }

    /** @return true quando terminou. */
    boolean tick() {
        if (!player.isAlive() || player.serverLevel() != level) return true;

        Vec3 from = player.position();
        player.setDeltaMovement(dir.scale(speed));
        player.hurtMarked = true;
        player.fallDistance = 0;

        AABB box = player.getBoundingBox().expandTowards(dir.scale(speed * 2.0D)).inflate(width * 0.5D, 0.3D, width * 0.5D);
        for (Entity e : level.getEntities(player, box, x -> x instanceof LivingEntity le && le.isAlive() && !le.isSpectator())) {
            LivingEntity target = (LivingEntity) e;
            if (target instanceof Player other && !player.canHarmPlayer(other)) continue;
            if (target instanceof TamableAnimal t && t.isOwnedBy(player)) continue;
            if (hit.add(target.getId())) strike(target);
        }

        trail(from);
        if (--ticksLeft <= 0) {
            finish();
            return true;
        }
        return false;
    }

    private void strike(LivingEntity target) {
        target.invulnerableTime = 0;
        target.hurt(level.damageSources().playerAttack(player), damage);
        target.knockback(0.9D, -dir.x, -dir.z);
        Vec3 c = target.position().add(0, target.getBbHeight() * 0.5D, 0);
        RandomSource r = level.random;
        for (int i = 0; i < 3; i++) Fx.slash(level, c, (r.nextDouble() - 0.5D) * 2.4D + 0.6D, 1.8D + r.nextDouble());
        Fx.burst(level, ParticleTypes.CRIT, c, 16, 0.4, 0.5);
        Fx.burst(level, ParticleTypes.SWEEP_ATTACK, c, 1, 0.0, 0.0);
        Fx.sound(level, c, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 1.3F);
        Fx.sound(level, c, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 0.9F);
        Fx.screen(level, c, 16, new FxPacket(FxPacket.SHAKE, 6, 0.35F, 0));
    }

    private void trail(Vec3 from) {
        RandomSource r = level.random;
        for (int i = 0; i < 4; i++) {
            Vec3 p = from.add(dir.scale(speed * i / 4.0D)).add(0, player.getBbHeight() * 0.5D, 0);
            Fx.burst(level, Fx.RED, p, 3, 0.35, 0.0);
            Fx.burst(level, ParticleTypes.ELECTRIC_SPARK, p, 2, 0.3, 0.05);
            Fx.burst(level, ParticleTypes.END_ROD, p, 1, 0.15, 0.02);
        }
        Vec3 mid = from.add(0, player.getBbHeight() * 0.55D, 0);
        Fx.slash(level, mid.subtract(dir.scale(0.6D)), (r.nextDouble() - 0.5D) * 0.5D + (ticksLeft % 2 == 0 ? 0.35D : -0.35D), 2.6D);
    }

    private void finish() {
        Vec3 pos = player.position().add(0, player.getBbHeight() * 0.5D, 0);
        player.setDeltaMovement(dir.scale(0.3D));
        player.hurtMarked = true;
        player.fallDistance = 0;
        Fx.slash(level, pos.add(dir.scale(1.6D)), -0.7, 4.5);
        Fx.slash(level, pos.add(dir.scale(1.6D)), 0.7, 4.5);
        Fx.burst(level, ParticleTypes.SWEEP_ATTACK, pos.add(dir), 1, 0.0, 0.0);
        Fx.burst(level, ParticleTypes.FLASH, pos, 1, 0.0, 0.0);
        Fx.sound(level, pos, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2F, 0.7F);
        Fx.sound(level, pos, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 1.6F);
    }
}
