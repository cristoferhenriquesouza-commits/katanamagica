package com.katanamagica;

import com.katanamagica.ability.AbilityManager;
import com.katanamagica.ability.TimeStopManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Eventos do lado comum (servidor logico). */
@Mod.EventBusSubscriber(modid = KatanaMagica.MODID)
public final class CommonEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        AbilityManager.tick(server);
        TimeStopManager.tick(server);
    }

    // ---- congelamento de seres vivos: o tick inteiro da entidade e cancelado
    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onKnockBack(LivingKnockBackEvent e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    /** Sem isso o i-frame (invulnerableTime) nunca diminuiria e o alvo congelado so levaria 1 golpe. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getSource().getEntity() instanceof Player attacker && TimeStopManager.isCaster(attacker)
                && TimeStopManager.isFrozen(e.getEntity())) {
            e.getEntity().invulnerableTime = 0;
        }
    }

    // ---- jogadores congelados nao agem
    @SubscribeEvent
    public static void onPlayerAttack(AttackEntityEvent e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (TimeStopManager.isFrozen(e.getPlayer())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onUseStart(LivingEntityUseItemEvent.Start e) {
        if (TimeStopManager.isFrozen(e.getEntity())) e.setCanceled(true);
    }

    // ---- ciclo de vida do jogador / servidor
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) AbilityManager.sync(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        AbilityManager.cancelSessions(e.getEntity().getUUID(), false);
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        AbilityManager.cancelSessions(e.getEntity().getUUID(), true);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        TimeStopManager.clearAll();
        AbilityManager.clearAll();
    }

    private CommonEvents() {}
}
