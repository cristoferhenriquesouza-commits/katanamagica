package com.katanamagica.network;

import com.katanamagica.ability.Ability;
import com.katanamagica.ability.AbilityManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> Servidor: o jogador pediu para ativar uma habilidade. */
public class ActivateAbilityPacket {
    private final int abilityId;

    public ActivateAbilityPacket(int abilityId) { this.abilityId = abilityId; }

    public static void encode(ActivateAbilityPacket m, FriendlyByteBuf buf) { buf.writeByte(m.abilityId); }

    public static ActivateAbilityPacket decode(FriendlyByteBuf buf) { return new ActivateAbilityPacket(buf.readByte()); }

    public static void handle(ActivateAbilityPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            Ability ability = Ability.byId(m.abilityId);
            if (player != null && ability != null) AbilityManager.request(player, ability);
        });
        c.setPacketHandled(true);
    }
}
