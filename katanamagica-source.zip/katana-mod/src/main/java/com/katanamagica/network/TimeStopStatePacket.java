package com.katanamagica.network;

import com.katanamagica.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: inicio/fim da parada temporal. */
public class TimeStopStatePacket {
    public final boolean active;
    public final int ticksLeft;
    public final int casterId;
    public final float radius;

    public TimeStopStatePacket(boolean active, int ticksLeft, int casterId, float radius) {
        this.active = active; this.ticksLeft = ticksLeft; this.casterId = casterId; this.radius = radius;
    }

    public static void encode(TimeStopStatePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active); buf.writeVarInt(m.ticksLeft); buf.writeVarInt(m.casterId); buf.writeFloat(m.radius);
    }

    public static TimeStopStatePacket decode(FriendlyByteBuf buf) {
        return new TimeStopStatePacket(buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readFloat());
    }

    public static void handle(TimeStopStatePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.timeStop(m)));
        ctx.get().setPacketHandled(true);
    }
}
