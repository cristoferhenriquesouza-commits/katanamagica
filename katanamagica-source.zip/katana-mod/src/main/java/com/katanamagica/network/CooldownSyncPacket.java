package com.katanamagica.network;

import com.katanamagica.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: recargas restantes/totais (em ticks) das 3 habilidades, para o HUD. */
public class CooldownSyncPacket {
    public final int[] remaining;
    public final int[] total;

    public CooldownSyncPacket(int[] remaining, int[] total) { this.remaining = remaining; this.total = total; }

    public static void encode(CooldownSyncPacket m, FriendlyByteBuf buf) {
        for (int i = 0; i < 3; i++) { buf.writeVarInt(m.remaining[i]); buf.writeVarInt(m.total[i]); }
    }

    public static CooldownSyncPacket decode(FriendlyByteBuf buf) {
        int[] r = new int[3], t = new int[3];
        for (int i = 0; i < 3; i++) { r[i] = buf.readVarInt(); t[i] = buf.readVarInt(); }
        return new CooldownSyncPacket(r, t);
    }

    public static void handle(CooldownSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.cooldowns(m)));
        ctx.get().setPacketHandled(true);
    }
}
