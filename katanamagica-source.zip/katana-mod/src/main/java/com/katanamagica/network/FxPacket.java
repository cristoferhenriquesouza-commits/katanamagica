package com.katanamagica.network;

import com.katanamagica.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: efeitos de tela (flash, tremor, FOV, carga). */
public class FxPacket {
    public static final byte DASH = 0;          // ticks = duracao do avanco
    public static final byte CHARGE_START = 1;  // ticks = duracao da carga
    public static final byte CHARGE_END = 2;    // carga terminou/cancelada
    public static final byte SHAKE = 3;         // ticks, strength
    public static final byte FLASH = 4;         // ticks, color (ARGB sem alpha)

    public final byte type;
    public final int ticks;
    public final float strength;
    public final int color;

    public FxPacket(byte type, int ticks, float strength, int color) {
        this.type = type; this.ticks = ticks; this.strength = strength; this.color = color;
    }

    public static void encode(FxPacket m, FriendlyByteBuf buf) {
        buf.writeByte(m.type); buf.writeVarInt(m.ticks); buf.writeFloat(m.strength); buf.writeInt(m.color);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readByte(), buf.readVarInt(), buf.readFloat(), buf.readInt());
    }

    public static void handle(FxPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.fx(m)));
        ctx.get().setPacketHandled(true);
    }
}
