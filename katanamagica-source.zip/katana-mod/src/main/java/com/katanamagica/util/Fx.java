package com.katanamagica.util;

import com.katanamagica.network.FxPacket;
import com.katanamagica.network.ModNetwork;
import com.katanamagica.registry.ModParticles;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Utilitarios de efeitos executados no servidor (as particulas chegam a todos os jogadores proximos). */
public final class Fx {
    public static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.95F, 0.05F, 0.08F), 1.6F);
    public static final DustParticleOptions RED_BIG = new DustParticleOptions(new Vector3f(1.0F, 0.1F, 0.1F), 2.6F);
    public static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(1.0F, 1.0F, 1.0F), 1.4F);

    /** Corte em crescente. roll em radianos, size = escala do sprite. */
    public static void slash(ServerLevel l, Vec3 p, double roll, double size) {
        l.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 0, roll, size, 0.0D, 1.0D);
    }

    /** Orbe de energia que percorre 'step' por tick durante sua vida (8 ticks). */
    public static void energy(ServerLevel l, Vec3 p, Vec3 step) {
        l.sendParticles(ModParticles.ENERGY.get(), p.x, p.y, p.z, 0, step.x, step.y, step.z, 1.0D);
    }

    public static void burst(ServerLevel l, ParticleOptions type, Vec3 p, int count, double spread, double speed) {
        l.sendParticles(type, p.x, p.y, p.z, count, spread, spread, spread, speed);
    }

    /** Particula com velocidade explicita (count 0 => offsets viram velocidade). */
    public static void directed(ServerLevel l, ParticleOptions type, Vec3 p, Vec3 vel) {
        l.sendParticles(type, p.x, p.y, p.z, 0, vel.x, vel.y, vel.z, 1.0D);
    }

    public static void sound(ServerLevel l, Vec3 p, SoundEvent s, float vol, float pitch) {
        l.playSound(null, p.x, p.y, p.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void screen(ServerLevel l, Vec3 center, double range, FxPacket pkt) {
        for (ServerPlayer pl : l.players()) {
            if (pl.position().distanceToSqr(center) <= range * range) ModNetwork.sendTo(pl, pkt);
        }
    }

    private Fx() {}
}
