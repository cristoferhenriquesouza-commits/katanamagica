package com.katanamagica;

import com.katanamagica.config.KatanaConfig;
import com.katanamagica.network.ModNetwork;
import com.katanamagica.registry.ModItems;
import com.katanamagica.registry.ModParticles;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(KatanaMagica.MODID)
public class KatanaMagica {
    public static final String MODID = "katanamagica";

    public KatanaMagica() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModParticles.PARTICLES.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::addToCreativeTabs);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, KatanaConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }

    private void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.KATANA);
        }
    }
}
