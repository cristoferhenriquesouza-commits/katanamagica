package com.katanamagica.registry;

import com.katanamagica.KatanaMagica;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, KatanaMagica.MODID);

    /** Corte em crescente. Parametros do servidor: xd = roll (rad), yd = tamanho. */
    public static final RegistryObject<SimpleParticleType> SLASH =
            PARTICLES.register("slash", () -> new SimpleParticleType(true));
    /** Orbe de energia. Parametros do servidor: xd,yd,zd = deslocamento por tick. */
    public static final RegistryObject<SimpleParticleType> ENERGY =
            PARTICLES.register("energy", () -> new SimpleParticleType(true));

    private ModParticles() {}
}
