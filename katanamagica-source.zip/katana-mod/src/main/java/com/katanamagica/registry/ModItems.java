package com.katanamagica.registry;

import com.katanamagica.KatanaMagica;
import com.katanamagica.item.KatanaItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, KatanaMagica.MODID);
    public static final RegistryObject<Item> KATANA = ITEMS.register("katana", KatanaItem::new);

    private ModItems() {}
}
