package com.katanamagica.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import org.jetbrains.annotations.Nullable;

/** Corte em crescente, sempre virado para a camera. xd = roll (rad), yd = tamanho. */
public class SlashParticle extends TextureSheetParticle {

    protected SlashParticle(ClientLevel level, double x, double y, double z, double roll, double size, SpriteSet sprites) {
        super(level, x, y, z);
        this.lifetime = 9;
        this.quadSize = (float) (size <= 0.0D ? 1.0D : size);
        this.roll = (float) roll;
        this.oRoll = this.roll;
        this.hasPhysics = false;
        this.gravity = 0.0F;
        this.xd = this.yd = this.zd = 0.0D;
        this.pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        float t = this.age / (float) this.lifetime;
        this.alpha = 1.0F - t * t;
        this.quadSize *= 1.05F;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 15728880;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) { this.sprites = sprites; }

        @Nullable
        @Override
        public net.minecraft.client.particle.Particle createParticle(SimpleParticleType type, ClientLevel level,
                                                                     double x, double y, double z, double xd, double yd, double zd) {
            return new SlashParticle(level, x, y, z, xd, yd, sprites);
        }
    }
}
