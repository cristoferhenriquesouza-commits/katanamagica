package com.katanamagica.client;

import com.katanamagica.KatanaMagica;
import com.katanamagica.ability.Ability;
import com.katanamagica.item.KatanaItem;
import com.katanamagica.network.ActivateAbilityPacket;
import com.katanamagica.network.ModNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

/** Eventos do cliente (barramento do Forge). */
@Mod.EventBusSubscriber(modid = KatanaMagica.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static final Random RNG = new Random();

    // ---------------------------------------------------------------- teclas + estado
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientState.tick(mc);
        if (mc.player == null || mc.level == null) return;
        handleKey(mc, KatanaKeys.TIME_STOP, Ability.TIME_STOP);
        handleKey(mc, KatanaKeys.LIGHTNING_SLASH, Ability.LIGHTNING_SLASH);
        handleKey(mc, KatanaKeys.SPECIAL_SLASH, Ability.SPECIAL_SLASH);
    }

    private static void handleKey(Minecraft mc, KeyMapping key, Ability ability) {
        while (key.consumeClick()) {
            if (mc.screen != null) continue;
            boolean holding = mc.player.getMainHandItem().getItem() instanceof KatanaItem
                    || mc.player.getOffhandItem().getItem() instanceof KatanaItem;
            if (!holding) {
                mc.player.displayClientMessage(Component.translatable("message.katanamagica.need_katana"), true);
                continue;
            }
            if (ClientState.isLocalFrozen(mc)) continue;
            int rem = ClientState.cdRemaining[ability.id];
            if (rem > 0) {
                mc.player.displayClientMessage(Component.translatable("message.katanamagica.cooldown",
                        String.format("%.1f", rem / 20.0F)), true);
                continue;
            }
            ModNetwork.CHANNEL.sendToServer(new ActivateAbilityPacket(ability.id));
        }
    }

    // ---------------------------------------------------------------- parada temporal (cliente)
    /** Congela visualmente seres vivos distantes do conjurador (animacoes, interpolacao, etc). */
    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent e) {
        if (!ClientState.timeStopActive || !e.getEntity().level().isClientSide) return;
        Minecraft mc = Minecraft.getInstance();
        if (e.getEntity() == mc.player || !e.getEntity().isAlive()) return;
        if (ClientState.isFrozenEntity(e.getEntity(), mc)) e.setCanceled(true);
    }

    /** O jogador congelado nao consegue andar nem pular. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        if (!ClientState.isLocalFrozen(Minecraft.getInstance())) return;
        var in = e.getInput();
        in.leftImpulse = 0; in.forwardImpulse = 0;
        in.up = in.down = in.left = in.right = false;
        in.jumping = false; in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered e) {
        if (ClientState.isLocalFrozen(Minecraft.getInstance())) {
            e.setCanceled(true);
            e.setSwingHand(false);
        }
    }

    /** Inversao de cores (apos mundo + mao, antes do HUD). */
    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (ClientState.timeStopActive && ClientState.shouldInvert(Minecraft.getInstance())) {
            TimeStopRenderer.render(e.getPartialTick());
        }
    }

    // ---------------------------------------------------------------- camera
    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        float f = e.getNewFovModifier();
        if (ClientState.dashTicks > 0) {
            float t = ClientState.dashTicks / (float) Math.max(1, ClientState.dashTotal);
            f *= 1.0F + 0.55F * Math.min(1.0F, t * 1.4F);
        }
        if (ClientState.chargeTicks > 0) {
            float prog = 1.0F - ClientState.chargeTicks / (float) Math.max(1, ClientState.chargeTotal);
            f *= 1.0F - 0.18F * prog;
        }
        if (ClientState.punchTicks > 0) f *= 1.0F + 0.3F * (ClientState.punchTicks / 8.0F);
        e.setNewFovModifier(f);
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles e) {
        float s = 0.0F;
        if (ClientState.shakeTicks > 0) s = ClientState.shakeStrength * (ClientState.shakeTicks / (float) Math.max(1, ClientState.shakeTotal));
        if (ClientState.chargeTicks > 0) {
            float prog = 1.0F - ClientState.chargeTicks / (float) Math.max(1, ClientState.chargeTotal);
            s = Math.max(s, 0.35F * prog * prog);
        }
        if (s <= 0.0F) return;
        e.setYaw(e.getYaw() + (RNG.nextFloat() - 0.5F) * 2.0F * s);
        e.setPitch(e.getPitch() + (RNG.nextFloat() - 0.5F) * 2.0F * s);
        e.setRoll(e.getRoll() + (RNG.nextFloat() - 0.5F) * 3.0F * s);
    }

    // ---------------------------------------------------------------- misc
    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        if (!(e.getItemStack().getItem() instanceof KatanaItem)) return;
        e.getToolTip().add(Component.translatable("tooltip.katanamagica.keys",
                KatanaKeys.TIME_STOP.getTranslatedKeyMessage(),
                KatanaKeys.LIGHTNING_SLASH.getTranslatedKeyMessage(),
                KatanaKeys.SPECIAL_SLASH.getTranslatedKeyMessage()).withStyle(ChatFormatting.DARK_GRAY));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
    }

    private ClientEvents() {}
}
