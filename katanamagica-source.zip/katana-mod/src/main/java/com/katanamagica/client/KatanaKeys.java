package com.katanamagica.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** As tres teclas. Todas aparecem em Opcoes > Controles > "Katana Magica" e podem ser remapeadas. */
public final class KatanaKeys {
    public static final String CATEGORY = "key.categories.katanamagica";

    public static final KeyMapping TIME_STOP = new KeyMapping("key.katanamagica.time_stop",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY);
    public static final KeyMapping LIGHTNING_SLASH = new KeyMapping("key.katanamagica.lightning_slash",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping SPECIAL_SLASH = new KeyMapping("key.katanamagica.special_slash",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);

    public static KeyMapping byAbility(int id) {
        return switch (id) { case 0 -> TIME_STOP; case 1 -> LIGHTNING_SLASH; default -> SPECIAL_SLASH; };
    }

    private KatanaKeys() {}
}
