package com.katanamagica.client;

import com.katanamagica.item.KatanaItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** HUD: recargas, barra de carga, flash de tela, vinheta de energia e contador da parada temporal. */
public final class KatanaHud {

    private static final String[] NAME_KEYS = {
            "hud.katanamagica.time_stop", "hud.katanamagica.lightning_slash", "hud.katanamagica.special_slash"};
    private static final int[] COLORS = {0xFF55FFFF, 0xFFFFDD33, 0xFFFF3030};

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font font = mc.font;

        // vinheta vermelha durante a carga
        if (ClientState.chargeTicks > 0) {
            float prog = 1.0F - ClientState.chargeTicks / (float) Math.max(1, ClientState.chargeTotal);
            int a = (int) (prog * 120);
            g.fillGradient(0, 0, w, h / 3, (a << 24) | 0xB00000, 0x00B00000);
            g.fillGradient(0, h * 2 / 3, w, h, 0x00B00000, (a << 24) | 0xB00000);
            int bw = 100, x = w / 2 - bw / 2, y = h - 62;
            g.fill(x - 1, y - 1, x + bw + 1, y + 5, 0xAA000000);
            g.fill(x, y, x + (int) (bw * prog), y + 4, 0xFFFF2020);
        }

        // flash
        if (ClientState.flashTicks > 0) {
            float t = ClientState.flashTicks / (float) Math.max(1, ClientState.flashTotal);
            int a = (int) (Math.min(1.0F, t * ClientState.flashStrength) * 215);
            g.fill(0, 0, w, h, (a << 24) | (ClientState.flashColor & 0xFFFFFF));
        }

        // contador da parada temporal
        if (ClientState.timeStopActive && ClientState.shouldInvert(mc)) {
            int secs = (ClientState.timeStopTicks + 19) / 20;
            g.drawCenteredString(font, Component.translatable("hud.katanamagica.time_stopped", secs), w / 2, 12, 0xFFFFFFFF);
        }

        // painel de recargas
        boolean holding = mc.player.getMainHandItem().getItem() instanceof KatanaItem
                || mc.player.getOffhandItem().getItem() instanceof KatanaItem;
        if (!holding) return;
        int sw = 66, sh = 24, gap = 4;
        int x0 = w - 3 * (sw + gap) - 4, y0 = h - sh - 4;
        for (int i = 0; i < 3; i++) {
            int x = x0 + i * (sw + gap);
            g.fill(x, y0, x + sw, y0 + sh, 0xA0000000);
            int rem = ClientState.cdRemaining[i];
            int tot = Math.max(1, ClientState.cdTotal[i]);
            if (rem > 0) {
                int fh = (int) (sh * (rem / (float) tot));
                g.fill(x, y0 + sh - fh, x + sw, y0 + sh, 0x80800000);
            }
            int c = COLORS[i];
            g.fill(x, y0, x + sw, y0 + 1, c);
            Component key = KatanaKeys.byAbility(i).getTranslatedKeyMessage();
            g.drawString(font, Component.literal("[").append(key).append("] ").append(Component.translatable(NAME_KEYS[i])), x + 3, y0 + 4, c);
            String status = rem > 0 ? String.format("%.1fs", rem / 20.0F) : "OK";
            g.drawString(font, status, x + 3, y0 + 14, rem > 0 ? 0xFFFF8888 : 0xFF88FF88);
        }
    }

    private KatanaHud() {}
}
