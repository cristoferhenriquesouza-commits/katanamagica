package com.katanamagica.client;

import com.google.gson.JsonSyntaxException;
import com.katanamagica.KatanaMagica;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

import java.io.IOException;

/**
 * Inversao de cores da tela durante a parada temporal.
 * Usa o programa de shader vanilla "invert" (assets/katanamagica/shaders/post/time_stop.json) com
 * InverseAmount = 1.0, processado logo depois do mundo e da mao e antes do HUD (mesma posicao do
 * post-effect vanilla), entao o HUD permanece legivel.
 */
public final class TimeStopRenderer {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final ResourceLocation CHAIN = new ResourceLocation(KatanaMagica.MODID, "shaders/post/time_stop.json");

    private static PostChain chain;
    private static boolean failed;
    private static int width, height;

    public static void render(float partialTick) {
        if (failed) return;
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getWidth();
        int h = mc.getWindow().getHeight();
        if (chain == null) {
            try {
                chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), CHAIN);
                chain.resize(w, h);
                width = w; height = h;
            } catch (IOException | JsonSyntaxException ex) {
                LOGGER.warn("Katana Magica: falha ao carregar o shader de inversao", ex);
                failed = true;
                chain = null;
                return;
            }
        }
        if (w != width || h != height) {
            chain.resize(w, h);
            width = w; height = h;
        }
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        chain.process(partialTick);
        mc.getMainRenderTarget().bindWrite(true);
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
    }

    public static void close() {
        if (chain != null) {
            chain.close();
            chain = null;
        }
        failed = false;
    }

    private TimeStopRenderer() {}
}
