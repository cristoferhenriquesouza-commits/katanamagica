package com.katanamagica.client;

import com.katanamagica.KatanaMagica;
import com.katanamagica.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registros do lado cliente (barramento do mod). */
@Mod.EventBusSubscriber(modid = KatanaMagica.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(KatanaKeys.TIME_STOP);
        e.register(KatanaKeys.LIGHTNING_SLASH);
        e.register(KatanaKeys.SPECIAL_SLASH);
    }

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent e) {
        e.registerSpriteSet(ModParticles.SLASH.get(), SlashParticle.Provider::new);
        e.registerSpriteSet(ModParticles.ENERGY.get(), EnergyParticle.Provider::new);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("katana_hud", KatanaHud::render);
    }

    private ClientModEvents() {}
}
