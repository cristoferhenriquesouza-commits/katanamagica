package com.katanamagica.client;

import com.katanamagica.network.CooldownSyncPacket;
import com.katanamagica.network.FxPacket;
import com.katanamagica.network.TimeStopStatePacket;

/** Executa no cliente o que chega do servidor. */
public final class ClientPacketHandler {

    public static void timeStop(TimeStopStatePacket m) {
        ClientState.setTimeStop(m.active, m.ticksLeft, m.casterId, m.radius);
    }

    public static void fx(FxPacket m) {
        switch (m.type) {
            case FxPacket.DASH -> { ClientState.dashTicks = ClientState.dashTotal = m.ticks + 4; ClientState.startShake(m.ticks + 4, 0.25F); }
            case FxPacket.CHARGE_START -> ClientState.chargeTicks = ClientState.chargeTotal = m.ticks;
            case FxPacket.CHARGE_END -> { ClientState.chargeTicks = 0; ClientState.punchTicks = 8; }
            case FxPacket.SHAKE -> ClientState.startShake(m.ticks, m.strength);
            case FxPacket.FLASH -> ClientState.startFlash(m.ticks, m.strength, m.color);
            default -> { }
        }
    }

    public static void cooldowns(CooldownSyncPacket m) {
        for (int i = 0; i < 3; i++) {
            ClientState.cdRemaining[i] = m.remaining[i];
            ClientState.cdTotal[i] = m.total[i];
        }
    }

    private ClientPacketHandler() {}
}
