package com.katanamagica.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Estado visual do cliente (alimentado por pacotes do servidor). */
public final class ClientState {
    // parada temporal
    public static boolean timeStopActive;
    public static int timeStopTicks, timeStopTotal;
    public static int casterId = -1;
    public static float radius;

    // recargas (HUD)
    public static final int[] cdRemaining = new int[3];
    public static final int[] cdTotal = new int[3];

    // efeitos de tela
    public static int dashTicks, dashTotal;
    public static int chargeTicks, chargeTotal;
    public static int shakeTicks, shakeTotal;
    public static float shakeStrength;
    public static int flashTicks, flashTotal, flashColor = 0xFFFFFF;
    public static float flashStrength = 1.0F;
    public static int punchTicks;

    private static boolean victimApplied;
    private static boolean victimNoGravity;

    public static void setTimeStop(boolean active, int ticks, int caster, float r) {
        timeStopActive = active;
        timeStopTicks = ticks;
        if (active) { timeStopTotal = Math.max(timeStopTotal, ticks); casterId = caster; radius = r; }
        else { timeStopTotal = 0; casterId = -1; }
    }

    public static void startFlash(int ticks, float strength, int color) {
        flashTicks = flashTotal = ticks; flashStrength = strength; flashColor = color;
    }

    public static void startShake(int ticks, float strength) {
        if (strength >= shakeStrength * (shakeTicks / (float) Math.max(1, shakeTotal))) {
            shakeTicks = shakeTotal = ticks; shakeStrength = strength;
        }
    }

    public static boolean isCaster(Minecraft mc) {
        return mc.player != null && mc.player.getId() == casterId;
    }

    /** Entidade dentro do raio da parada temporal e que nao e o conjurador? */
    public static boolean isFrozenEntity(Entity e, Minecraft mc) {
        if (!timeStopActive || mc.level == null || e.getId() == casterId) return false;
        Entity caster = mc.level.getEntity(casterId);
        if (caster == null) return false;
        return e.distanceToSqr(caster) <= (double) radius * radius;
    }

    public static boolean isLocalFrozen(Minecraft mc) {
        return mc.player != null && isFrozenEntity(mc.player, mc);
    }

    /** A inversao de cores aparece para o conjurador e para quem esta dentro do raio. */
    public static boolean shouldInvert(Minecraft mc) {
        if (!timeStopActive || mc.player == null) return false;
        if (isCaster(mc)) return true;
        Entity caster = mc.level == null ? null : mc.level.getEntity(casterId);
        return caster != null && mc.player.distanceToSqr(caster) <= (double) radius * radius;
    }

    public static void tick(Minecraft mc) {
        for (int i = 0; i < 3; i++) if (cdRemaining[i] > 0) cdRemaining[i]--;
        if (dashTicks > 0) dashTicks--;
        if (chargeTicks > 0) chargeTicks--;
        if (shakeTicks > 0) shakeTicks--;
        if (flashTicks > 0) flashTicks--;
        if (punchTicks > 0) punchTicks--;
        if (timeStopActive && --timeStopTicks <= 0) setTimeStop(false, 0, -1, 0);

        // jogador-alvo congelado: sem fisica local (a posicao e imposta pelo servidor)
        LocalPlayer lp = mc.player;
        boolean victim = lp != null && isLocalFrozen(mc);
        if (victim) {
            if (!victimApplied) { victimNoGravity = lp.isNoGravity(); victimApplied = true; }
            lp.setNoGravity(true);
            lp.setDeltaMovement(Vec3.ZERO);
        } else if (victimApplied) {
            if (lp != null) lp.setNoGravity(victimNoGravity);
            victimApplied = false;
        }
    }

    public static void reset() {
        timeStopActive = false; timeStopTicks = timeStopTotal = 0; casterId = -1;
        dashTicks = chargeTicks = shakeTicks = flashTicks = punchTicks = 0;
        for (int i = 0; i < 3; i++) { cdRemaining[i] = 0; cdTotal[i] = 0; }
        victimApplied = false;
        TimeStopRenderer.close();
    }

    private ClientState() {}
}
